import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rick_and_morty/providers/charecterProvider.dart';
import 'package:rick_and_morty/widgets/characterCard.dart';
import 'api/getCharacter.dart';
import 'api/models/character.dart';
import 'constants/colors.dart';
import 'api/sqlite.dart';

class CharactersPage extends StatefulWidget {
  @override
  _CharactersPageState createState() => _CharactersPageState();
}

class _CharactersPageState extends State<CharactersPage> {
  final ApiGetCharecters apiService = ApiGetCharecters();
  List<Character> characters = [];
  String? nextPage;
  bool isLoading = false;
  late ScrollController scrollController;


  @override
  void initState() {
    super.initState();
    scrollController = ScrollController();
    scrollController.addListener(_scrollListener);
    fetchData();
  }

  void _scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent && !isLoading) {
      if (nextPage != null) {
        fetchData(url: nextPage!);
      }
    }
  }

  Future<void> fetchData({String url = "https://rickandmortyapi.com/api/character/"}) async {
    if (isLoading) return;
    setState(() {
      isLoading = true;
    });

    try {
      final result = await apiService.fetchCharacters(url);
      setState(() {
        characters.addAll(result['characters']);
        nextPage = result['nextPage'];
      });

      for (var character in result['characters']) {
        await DatabaseHelper.instance.insertCharacter(character);
      }
    } catch (e) {
      print("Error: $e");

      if (nextPage == null) {
        final allCharacters = await DatabaseHelper.instance.getAllCharacters();
        setState(() {
          characters = allCharacters;
        });
      }
    }

    await _refreshFavorites(); // обновление фаворитов после каждой загрузки
    setState(() {
      isLoading = false;
    });
  }

  Future<void> _refreshFavorites() async {
    final favorites = await DatabaseHelper.instance.getFavoriteCharacters();
    setState(() {
      characters = characters.map((c) {
        final isFavorite = favorites.any((f) => f.id == c.id);
        c.isFavorite = isFavorite;
        return c;
      }).toList();
    });
  }

  void _refresh(){
    setState(() {

    });
  }


  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final characterProvider = Provider.of<CharacterProvider>(context);
    return ListView.builder(
      controller: scrollController,
      itemCount: characters.length + (nextPage != null ? 1 : 0),  // Если есть следующая страница, показываем индикатор загрузки
      itemBuilder: (context, index) {
        if (index == characters.length) {
          return Center(
            child: CircularProgressIndicator(
              color: greenColor,
            ),
          );
        }
        final character = characters[index];
        return CharacterCard(
            character: character,
            onFavoriteChanged: _refresh,
        );  // Отображение карточки персонажа
      },
    );
  }
}
