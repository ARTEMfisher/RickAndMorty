import 'package:flutter/material.dart';

const Color greenColor = Color.fromRGBO(151, 206, 76, 1);
const Color redColor = Color.fromRGBO(231, 82, 18, 1);
const Color greyColor = Color.fromRGBO(157, 160, 174, 1);
const Color goldColor = Color.fromRGBO(255,215,0,1);
const Color lightGreyColor = Color.fromRGBO(220, 220, 220, 1);